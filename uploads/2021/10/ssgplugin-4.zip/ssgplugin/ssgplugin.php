<?php
/**
 * Plugin name: SSG Plugin 
 * Description: A plugin for goodmorning, evening and night.
 */

 function examplefunction(){
     $message = 'A basic plugin for me, yes.';
     return $message;
 }
 add_shortcode('ssgplugin', 'examplefunction');
?>